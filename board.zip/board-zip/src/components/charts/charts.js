import React from "react";
import { Line, Bar, Pie, Doughnut } from "react-chartjs-2";
function Chart(props) {
  const chartData = props.chartData.map(data => data.count);
  const chartLabels = props.chartData.map(
    data => data.year + "/" + data.quarter
  );
  let backgroundColors = [];
  if (props.type === "line") {
    backgroundColors.push("#75ded8");
  } else {
    for (let i = 0; i < chartData.length; i++) {
      let color =
        props.type === "bar"
          ? "#75ded8"
          : `rgb(${Math.floor(Math.random() * 255 + 1)},${Math.floor(
              Math.random() * 255 + 1
            )},${Math.floor(Math.random() * 255 + 1)},0.6)`;
      backgroundColors.push(color);
    }
  }
  const data = {
    labels: chartLabels,
    datasets: [
      {
        label: "Hello",
        data: chartData,
        backgroundColor: [...backgroundColors],
        bordercolor: ""
      }
    ]
  };
  let toggleStatus = true;
  let onclickActiveStatus = false;
  const options = {
    title: {
      text: props.type.toUpperCase() + " Chart",
      display: true,
      fontSize: 25
    },
    legend: {
      display: true,
      position: "bottom",
      labels: {
        fontColor: "#60CEEB"
      },
      onClick: function() {
        onclickActiveStatus = true;
      }
    },
    layout: {
      padding: {
        left: 10,
        top: 0,
        right: 30,
        bottom: 0
      }
    },
    tooltips: {
      enabled: true
    }
  };
  function toggleChart() {
    toggleStatus = !toggleStatus;
    return toggleStatus ? (
      <Bar data={data} options={options} />
    ) : (
      <Line data={data} options={options} />
    );
  }
  function chartType() {
    if (onclickActiveStatus) return toggleChart();
    switch (props.type) {
      case "bar":
        return <Bar data={data} options={options} />;
      case "pie":
        return <Pie data={data} options={options} />;
      case "doughnut":
        return <Doughnut data={data} options={options} />;
      default:
        return <Line data={data} options={options} />;
    }
  }
  return <React.Fragment>{chartType()}</React.Fragment>;
}
export default Chart;
