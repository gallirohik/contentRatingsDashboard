import React, { Component } from "react";
import DataGrid from "./dataGrid/dataGrid";
import Chart from "./charts/charts";
import { FormattedMessage } from "react-intl";
import "./dataGrid.css";
class MainContent extends Component {
  constructor() {
    super();
    this.name = "";
    this.state = {
      columnDefs: [
        {
          headerName: "Name",
          field: "name",
          checkboxSelection: true,
          sortable: true,
          filter: true,
          cellClass: function(params) {
            return params.rowIndex % 2 ? ["row-1"] : ["row-2"];
          }
        },
        {
          headerName: "Year",
          field: "year",
          sortable: true,
          filter: true,
          cellClass: function(params) {
            return params.rowIndex % 2 ? ["row-1"] : ["row-2"];
          }
        },
        {
          headerName: "Quarter",
          field: "quarter",
          sortable: true,
          filter: true,
          cellClass: function(params) {
            return params.rowIndex % 2 ? ["row-1"] : ["row-2"];
          }
        },
        {
          headerName: "Count",
          field: "count",
          sortable: true,
          filter: true,
          cellClass: function(params) {
            return params.rowIndex % 2 ? ["row-1"] : ["row-2"];
          }
        }
      ],
      rowData: [],
      chartData: [],
      ChartLabels: [],
      display: false,
      type: "line"
    };
    this.generateChart = this.generateChart.bind(this);
    this.setType = this.setType.bind(this);
  }
  componentDidMount() {
    fetch("https://nataliia-radina.github.io/react-vis-example/")
      .then(response => response.json())
      .then(data => {
        this.setState({
          rowData: data.results
        });
      });
  }
  generateChart(name) {
    this.name = name;
    this.setState(prevState => {
      const chartData = prevState.rowData.filter(data => data.name === name);
      return { chartData };
    });
    this.setState({ display: true });
    console.log(this.state.rowData);
  }
  setType(type) {
    this.setState({ type });
  }
  render() {
    return (
      <React.Fragment>
        <section className="section">
          <div className="container">
            <h1 className="title">
              <FormattedMessage
                id="mainContent.title.text"
                defaultMessage="Statistics with amounts of pull-requests per programming language on Github"
              />
            </h1>
            <h2 className="subtitle">
              <FormattedMessage
                id="mainContent.subtitle.message1"
                defaultMessage="Select any one of the"
              />{" "}
              <strong>
                <FormattedMessage
                  id="mainContent.subtitle.message2"
                  defaultMessage="Programming Language"
                />
              </strong>
              ,
              <FormattedMessage
                id="mainContent.subtitle.message3"
                defaultMessage="to visualize"
              />{" "}
              <strong>
                <FormattedMessage
                  id="mainContent.subtitle.message4"
                  defaultMessage="Charts"
                />
              </strong>
              .
            </h2>
            <div className="parent-grid-container">
              <div className="grid-container">
                <DataGrid
                  columnDefs={this.state.columnDefs}
                  rowData={this.state.rowData}
                  rowSelection={"single"}
                  generateChart={this.generateChart}
                />
              </div>
            </div>
          </div>
        </section>
        {this.state.display ? (
          <div>
            <br />

            <div class="columns is-centered">
              <div class="notification is-info column is-8 is-size-5 ">
                <p>
                  Currently you are viewing <strong>{this.name}</strong> Charts
                </p>
              </div>
            </div>
            <div className="columns">
              <div className="column is-half">
                <Chart chartData={this.state.chartData} type={"line"} />
              </div>
              <div className="column">
                <Chart chartData={this.state.chartData} type={"bar"} />
              </div>
            </div>
            <div className="columns">
              <div className="column is-half">
                <Chart chartData={this.state.chartData} type={"pie"} />
              </div>
              <div className="column">
                <Chart chartData={this.state.chartData} type={"doughnut"} />
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </React.Fragment>
    );
  }
}
export default MainContent;
/*<div className="line-chart">
            <LineChart
              chartData={this.state.chartData}
              type={this.state.type}
            />
            <span>
              <button onClick={() => this.setType("line")}>Line</button>
            </span>
            <span>
              <button onClick={() => this.setType("bar")}>Bar</button>
            </span>
            <span>
              <button onClick={() => this.setType("pie")}>Pie</button>
            </span>
            <span>
              <button onClick={() => this.setType("doughnut")}>Doughnut</button>
            </span>
          </div>*/
