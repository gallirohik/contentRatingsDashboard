import React, { Component } from "react";
import { FormattedMessage } from "react-intl";
class Footer extends Component {
  render() {
    return (
      <div>
        <footer className="footer">
          <div className="content has-text-centered">
            <strong>
              <FormattedMessage
                id="footer.message"
                defaultMessage="DashBoard"
              />
            </strong>{" "}
            by{" "}
            <a href="https://valuelabs.facebook.com/profile.php?id=100030664552742">
              Rohik Galli
            </a>
            .
          </div>
        </footer>
      </div>
    );
  }
}

export default Footer;
