import React, { Component } from "react";
import { FormattedMessage } from "react-intl";
import "./header.css";
class Header extends Component {
  render() {
    return (
      <section className="hero has-background-black">
        <div className="hero-body">
          <div className="container">
            <h1 className="title is-2 title-message">
              <FormattedMessage
                id="header.message"
                defaultMessage="DashBoard"
              />
            </h1>
          </div>
        </div>
      </section>
    );
  }
}

export default Header;
